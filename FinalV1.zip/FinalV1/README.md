# mist7570efinal
Final project for Programming I class. 

# Scenario: 
Most online retailer sites include some common core functionality. Customers can browse an online catalog, they can add items to their shopping cart, they can remove items from their cart, and they can purchase items. For many sites, customers can become registered members. For this project, you are to create some of the use cases for an online retail site. You may choose a primary theme of your site or just include general merchandise. You make work in a team of one, two or three people.

Basic e-commerce website with login, inventory management, and cart.
Concepts include:
* Http requests
* Encrypted login
* SQL database
* State management
* HTML/CSS
